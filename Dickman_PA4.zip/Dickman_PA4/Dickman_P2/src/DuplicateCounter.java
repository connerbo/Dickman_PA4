// IMPORTS
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// DUPLICATE COUNTER PROGRAM
public class DuplicateCounter {

    // WORD COUNTER - Instance Variable
    private Map<String, Integer> wordCounter;

    public DuplicateCounter(){ wordCounter = new HashMap<String,Integer>(); }

    // COUNT - Input File
    public void count(String fileName){

        Scanner dataFile = null;

        try {
            dataFile = new Scanner(new File(fileName));
        } catch (FileNotFoundException e) { System.out.println(e.getMessage()); }

        dataFile.useDelimiter("([0-9]|[.,!?:;'\"-]|\\s)+");

        while(dataFile.hasNext()) {

            String word = dataFile.next().toLowerCase();
            Integer count = wordCounter.get(word);

            if(count == null) count = 1;

            else count = count + 1;

            wordCounter.put(word, count);

        }

        dataFile.close();

    }

    // WRITE - Output File
    public void write(String fileName){

        try {

            PrintWriter outputFile = new PrintWriter(new File(fileName));

            for(String myString : wordCounter.keySet()) {
                outputFile.println(myString + " " + wordCounter.get(myString));
            }

            outputFile.close();

        } catch (FileNotFoundException e) { System.out.println(e.getMessage()); }

    }

}
